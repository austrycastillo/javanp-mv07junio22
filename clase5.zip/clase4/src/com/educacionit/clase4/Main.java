package com.educacionit.clase4;

import java.util.Scanner;

import javax.swing.JOptionPane;

public class Main {

	public static void main(String[] args) {
		/*
		 * if anidados if(){} else if(){} else if(){} else if(){} else{}
		 * 
		 * if(){ if(){} }
		 */
		/*
		 * VAMOS AL BOLICHE --->PUEDEN ENTRAR PERSONAS ENTRE 18 Y 25 AÑOS --->SI TIENES
		 * 22 TE DAN UNA BEBIDA GRATIS DESARROLLAR UN SISTEMA PARA VERIFICAR E INDICAR
		 * SI PUEDE PASAR O NO Y SI GANA EL PREMIO
		 */
		Scanner teclado = new Scanner(System.in);
		/*
		 * int edad, min = 18, max = 25, premio = 22; System.out.println("Tu edad??");
		 * edad = teclado.nextInt(); if (edad >= min && edad <= max) {
		 * System.out.println("Bienvenidos al Boliche!!"); if (edad == premio)
		 * System.out.println("tienen una bebida gratis!!"); } else {
		 * System.out.println("Ups no puedes pasar!"); if (edad < 18)
		 * System.out.println("Por bebito"); else System.out.println("Por viejito"); }
		 */

		/*
		 * SOLICITAR UN NÚMERO POR TECLADO INDICAR SI TIENE UNA CIFRA(<10), DOS(<100),
		 * TRES, CUATRO O MÁS CIFRAS
		 */
		/*
		 * int numero; System.out.println("Escribe un número"); numero =
		 * teclado.nextInt(); if (numero >0 && numero < 10) {
		 * System.out.println("número tiene una sola cifra"); } else if (numero < 100) {
		 * System.out.println("número tiene dos cifras"); } else if (numero < 1000) {
		 * System.out.println("número tiene tres cifras"); } else if (numero < 10000) {
		 * System.out.println("número tiene cuatro cifras"); } else if (numero < 100000)
		 * { System.out.println("número tiene cinco o más cifras"); } else {
		 * System.out.println("Dato incorrecto"); }
		 */

		/*
		 * switch(variable){ case a: instrucciones..... break; case b:
		 * instrucciones..... break; default: instrucciones...
		 * 
		 * }
		 */
		/*
		 * String dia = "domingo"; switch (dia) { case "lunes":
		 * System.out.println("Hoy es lunes de inicios"); break; case "martes":
		 * System.out.println("Hoy es martes de asado"); break; case "miércoles":
		 * System.out.println("Hoy es miércoles de helado"); break; case "jueves":
		 * System.out.println("Hoy es jueves de pizza"); break; case "viernes":
		 * System.out.println("Hoy es viernes de vino"); break; default:
		 * System.out.println("Fin de semana!!"); }
		 */

		/*
		 * solicitar al usuario dos números y mostrar un menú de opciones, ej suma(+)
		 * resta(-) multiplicación(*)división(/) realizar la operación seleccionada
		 */

		/*
		 * double num1, num2; String opcion, mensaje="";
		 * System.out.println("Escribe un número"); num1 = teclado.nextDouble();
		 * System.out.println("Escribe otro número"); num2 = teclado.nextDouble();
		 * System.out.println("Escribe el signo de la operación a realizar:");
		 * System.out.
		 * println("\tsuma(+) \n\tresta(-) \n\tmultiplicación(*) \n\tdivisión(/)");
		 * opcion= teclado.next(); System.out.println(opcion); if(!opcion.equals("+") &&
		 * !opcion.equals("-") && !opcion.equals("*") && !opcion.equals("/")) {
		 * System.out.println("Esa opción no existe!"); }else {
		 * //System.out.println("la tarea"); switch(opcion) { case "+": mensaje =
		 * "La suma de " + num1 + " y " + num2 + " es igual a: " + (num1 + num2); break;
		 * case "-": mensaje = "La resta de " + num1 + " y " + num2 + " es igual a: " +
		 * (num1 - num2); break; case "*": mensaje = "La multiplicación de " + num1 +
		 * " y " + num2 + " es igual a: " + (num1 * num2); break; case "/": mensaje =
		 * "La división de " + num1 + " y " + num2 + " es igual a: " + (num1 / num2);
		 * break; } System.out.println(mensaje); }
		 */

		// bucles
		/*
		 * while(condición){ instrucciones ajuste }
		 */
		/*
		 * byte a = 1; while (a <= 100) { System.out.println(a + " Hoy es viernesssss");
		 * a++;//a = a + 1; }
		 */

		/*
		 * DESARROLLAR UN ALGORITMO QUE PERMITA IMPRIMIR EN LA CONSOLA LOS NÚMEROS DEL
		 * 500 AL 1000 DE 5 EN 5 Y QUE NO MUESTRE EN PANTALLA EL NÚMERO 700 NI EL NÚMERO
		 * 750
		 */
		/*
		 * short min = 500, max = 1000; while (min <= max) { if (min != 700 && min !=
		 * 750) { System.out.println(min); } min += 5; }
		 */

		/*
		 * do{ instrucciones ajuste }while(condición);
		 */
		/*
		 * int c = 1; do { System.out.println(c); c--; }while(c > 2);
		 */

		/*
		 * int resp = JOptionPane.showConfirmDialog(null, "¿Te gustan los viernes?");
		 * System.out.println(JOptionPane.OK_OPTION); if(resp == 0)
		 * System.out.println("a mi también me gustan ;)"); else if(resp == 1)
		 * System.out.println("te respeto tu opinión "); else
		 * System.out.println("Ups no te gustó la pregunta");
		 */
		/*
		 * String palabra = JOptionPane.showInputDialog("Escribe una palabra");
		 * System.out.println(palabra); int numero
		 * =Integer.parseInt(JOptionPane.showInputDialog("Escribe una palabra"));
		 */
		// 0 si 1 no 2 cancel
		/*
		 * DESARROLLAR UN JUEGO DE ADIVINA EL NÚMERO DEBES PREGUNTAR AL USUARIO SI
		 * QUIERE SEGUIR JUGANDO UTILIZANDO DO WHILE
		 * 
		 *   int random_int = (int)Math.floor(Math.random()*(max-min+1)+min);
		 */
		int resp = 0, numero = 0, adivina = 2;
		do {
			numero = Integer.parseInt(JOptionPane.showInputDialog("Jugamos! ¿Escribe el número secreto?"));
			if (numero == adivina)
				JOptionPane.showMessageDialog(null, "ganaste!!");
			else
				JOptionPane.showMessageDialog(null, "perdiste!!");
			resp = JOptionPane.showConfirmDialog(null, "¿Quieres seguir jugando?");
		} while (JOptionPane.OK_OPTION == resp);
		System.out.println("Terminaste el juego");
	}

}

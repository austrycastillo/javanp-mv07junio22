package com.educacionit.clase4;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		/*
		 * if anidados if(){} else if(){} else if(){} else if(){} else{}
		 * 
		 * if(){ if(){} }
		 */
		/*
		 * VAMOS AL BOLICHE --->PUEDEN ENTRAR PERSONAS ENTRE 18 Y 25 AÑOS --->SI TIENES
		 * 22 TE DAN UNA BEBIDA GRATIS DESARROLLAR UN SISTEMA PARA VERIFICAR E INDICAR
		 * SI PUEDE PASAR O NO Y SI GANA EL PREMIO
		 */
		Scanner teclado = new Scanner(System.in);
		/*
		 * int edad, min = 18, max = 25, premio = 22; System.out.println("Tu edad??");
		 * edad = teclado.nextInt(); if (edad >= min && edad <= max) {
		 * System.out.println("Bienvenidos al Boliche!!"); if (edad == premio)
		 * System.out.println("tienen una bebida gratis!!"); } else {
		 * System.out.println("Ups no puedes pasar!"); if (edad < 18)
		 * System.out.println("Por bebito"); else System.out.println("Por viejito"); }
		 */

		/*
		 * SOLICITAR UN NÚMERO POR TECLADO INDICAR SI TIENE UNA CIFRA(<10), DOS(<100),
		 * TRES, CUATRO O MÁS CIFRAS
		 */
		/*
		 * int numero; System.out.println("Escribe un número"); numero =
		 * teclado.nextInt(); if (numero >0 && numero < 10) {
		 * System.out.println("número tiene una sola cifra"); } else if (numero < 100) {
		 * System.out.println("número tiene dos cifras"); } else if (numero < 1000) {
		 * System.out.println("número tiene tres cifras"); } else if (numero < 10000) {
		 * System.out.println("número tiene cuatro cifras"); } else if (numero < 100000)
		 * { System.out.println("número tiene cinco o más cifras"); } else {
		 * System.out.println("Dato incorrecto"); }
		 */

		/*
		 * switch(variable){ case a: instrucciones..... break; case b:
		 * instrucciones..... break; default: instrucciones...
		 * 
		 * }
		 */
		/*String dia = "domingo";
		switch (dia) {
		case "lunes":
			System.out.println("Hoy es lunes de inicios");
			break;
		case "martes":
			System.out.println("Hoy es martes de asado");
			break;
		case "miércoles":
			System.out.println("Hoy es miércoles de helado");
			break;
		case "jueves":
			System.out.println("Hoy es jueves de pizza");
			break;
		case "viernes":
			System.out.println("Hoy es viernes de vino");
			break;
		default:
			System.out.println("Fin de semana!!");
		}*/
		
		/*
		 * solicitar al usuario dos números y
		 mostrar un menú de opciones, ej suma(+) resta(-) multiplicación(*)división(/)
		 realizar la operación seleccionada
		 */
		
		double num1, num2;
		String opcion;
		System.out.println("Escribe un número");
		num1 = teclado.nextDouble();
		System.out.println("Escribe otro número");
		num2 = teclado.nextDouble();
		System.out.println("Escribe el signo de la operación a realizar:");
		System.out.println("\tsuma(+) \n\tresta(-) \n\tmultiplicación(*) \n\tdivisión(/)");
		opcion= teclado.next();
		System.out.println(opcion);
		if(!opcion.equals("+")) {
			System.out.println("Esa opción no existe!");
		}else {
			System.out.println("la tarea");
		}
	}

}

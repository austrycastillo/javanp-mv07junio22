package practica;

import java.util.Scanner;

public class App {
    public static void main(String[] args) {
        // // casteo implicito
        // byte a = 2;
        // System.out.println(a);
        // int b = a;
        // System.out.println(b);
        // // casteo explicito
        // short c = (short) b;
        // System.out.println(c);
        // b = 12345678;
        // a = (byte) b;
        // System.out.println(a);
        // // funciones de java
        // String texto = " Hoy es martes de amor ";
        // System.out.println(texto);
        // System.out.println(texto.trim());// elimina espacios al inio y al final
        // System.out.println(texto.toUpperCase());
        // System.out.println(Math.random());// aleatorio 0 y 1
        // System.out.println(Math.random() * 10);
        // System.out.println(Math.ceil(Math.random() * 10));
        // System.out.println(Math.random() * 500 + 100);
        // //(Math.random() * (66 - 18)) + 18;
        // System.out.println((Math.random() * (66 - 18)) + 18);
        // System.out.println(Math.round(Math.random() * (66 - 18)) + 18);
        // estructuras de control
        /*
         * if(condición){//instrucciones}
         * if(condición){//instrucciones}else{//instrucciones}
         */
        int x = 258, y = 505;
        // determinar si x es menor (if)
        if (x < y) {
            System.out.println("Si es menor");
        }
        // determinar si y es mayor o menor
        if (y > x) {
            System.out.println(y + " es mayor que " + x);
        } else {
            System.out.println(y + " es menor que " + x);
        }
        /*
         * Desarrollar un programa que solicite con scanner
         * los datos de acceso al usuario (login y pass)
         * verificar si son correctos y mostrar un mensaje
         * de bienvenida o error
         */
        Scanner teclado = new Scanner(System.in);
        String loginUser, loginBD = "admin", passUser, passBD = "abc123";
        System.out.println("Escribe tu login");
        loginUser = teclado.next();
        loginUser = loginUser.toLowerCase();// llevar a minuscula
        System.out.println("Escribe tu clave secreta");
        passUser = teclado.next();
        if (loginBD.equals(loginUser) && passBD.equals(passUser)) {
            System.out.println("Bienvenido al sistema");
        } else {
            System.out.println("Error datos incorrectos");
        }
    }
}
